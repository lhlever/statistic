package test;

import java.net.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;



import java.io.*;
 
public class Test
{
	//�ͻ���
	public static void name() throws UnknownHostException, IOException { 
		   		Socket socket = new Socket("127.0.0.1", 9999);
		   		SimpleDateFormat formatTime = new SimpleDateFormat("HH:mm:ss");
		   		SimpleDateFormat formatDate = new SimpleDateFormat("yyyy-MM-dd");
		   		Date date = new Date();
		   		String time=formatTime.format(date);
		   		BufferedWriter writer=new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
		   		writer.write(time);
		   		writer.newLine();
		   		writer.flush();
		   		System.out.println("���ڻỰ......");
		   		
		   		Record record=new Record();
		   		record.setRoomNumber("B401");
		   		//�����·�����µľ�����
		   		//record.setIpNumber(InetAddress.getLocalHost().getHostAddress());
		   		record.setIpNumber("127.0.0.1");
		   		record.setMacNumber(getLocalMac(InetAddress.getLocalHost()));
		   		record.setFirstTime(time);
		   		record.setLastTime(null);
		   		record.setData(formatDate.format(date));
		   		
		   		ObjectOutputStream objectOutputStream=new ObjectOutputStream(socket.getOutputStream());
		   		objectOutputStream.writeObject(record);
//		   		BufferedWriter writer=new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
		   		BufferedReader reader=new BufferedReader(new InputStreamReader(socket.getInputStream()));
		   		String message=null;
		   		//readLine()�����������/r /n /r/n��Ϊһ�е��жϱ�־
		   		while((message=reader.readLine())!=null) {
		   			System.out.println("��ȡ����������Ϊ------------>"+message);
		   			if(("ever").equals(message)) {
		   				writer.write("ever");
		   				//newLine()��������/r/n�������µ�һ��
		   				writer.newLine();
		   				writer.flush();
		   			}
		   		}
		   		
		   		objectOutputStream.flush();
		   		objectOutputStream.close();
		        socket.close();
		       // System.out.println("ͨ�Ž���");
	}
	private static String  getLocalMac(InetAddress ia) throws SocketException {
		// TODO Auto-generated method stub
		//��ȡ��������ȡ��ַ
		byte[] mac = NetworkInterface.getByInetAddress(ia).getHardwareAddress();
		//System.out.println("mac���鳤�ȣ�"+mac.length);
		StringBuffer sb = new StringBuffer("");
		for(int i=0; i<mac.length; i++) {
			if(i!=0) {
				sb.append("-");
			}
			//�ֽ�ת��Ϊ����
			int temp = mac[i]&0xff;
			String str = Integer.toHexString(temp);
			//System.out.println("ÿ8λ:"+str);
			if(str.length()==1) {
				sb.append("0"+str);
			}else {
				sb.append(str);
			}
		}
		//System.out.println("����MAC��ַ:"+sb.toString().toUpperCase());
		return sb.toString().toUpperCase();
	}
   public static void main(String [] args) 
   {
	   Timer timer=new Timer();
	   TimerTask task=new TimerTask() {
		
		@Override
		public void run() {
			// TODO Auto-generated method stub
			try {
				name();
				
			} catch (UnknownHostException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	};
//	timer.schedule(task, 1000,50000);
	timer.schedule(task,5000);
   }
}
