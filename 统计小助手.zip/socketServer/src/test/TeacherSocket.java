package test;

import java.io.BufferedWriter;
import java.io.ObjectInputStream;
import java.net.Socket;

public class TeacherSocket {
	private Socket socket;
	private ObjectInputStream objectInputStream;
	private BufferedWriter bufferedWriter;
	public Socket getSocket() {
		return socket;
	}
	public void setSocket(Socket socket) {
		this.socket = socket;
	}
	public ObjectInputStream getObjectInputStream() {
		return objectInputStream;
	}
	public void setObjectInputStream(ObjectInputStream objectInputStream) {
		this.objectInputStream = objectInputStream;
	}
	public BufferedWriter getBufferedWriter() {
		return bufferedWriter;
	}
	public void setBufferedWriter(BufferedWriter bufferedWriter) {
		this.bufferedWriter = bufferedWriter;
	}
	
}
