package test;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class Server {
//	public static ArrayList<TeacherSocket> list=new ArrayList<>();
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("������Ѿ�����������������");
		try {
			ServerSocket serverSocket=new ServerSocket(3333);
			TeacherSocket teacherSocket=null;
			ScheduledExecutorService pool = Executors.newScheduledThreadPool(1);
			while(true) {
				Socket socket=serverSocket.accept();
				System.out.println(socket.getRemoteSocketAddress()+"������");
				teacherSocket=new TeacherSocket();
				teacherSocket.setSocket(socket);
				teacherSocket.setObjectInputStream(new ObjectInputStream(teacherSocket.getSocket().getInputStream()));
				teacherSocket.setBufferedWriter(new BufferedWriter(new OutputStreamWriter(teacherSocket.getSocket().getOutputStream())));
//				list.add(teacherSocket);
				OverThread overThread=new OverThread(teacherSocket);
				System.out.println("�������߳�");
				//�ӳ�0���ӣ����10����
				pool.scheduleWithFixedDelay(overThread, 0,1, TimeUnit.SECONDS);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
class OverThread implements Runnable{
	private TeacherSocket teacherSocket;
	public Database database=new Database();
	public static SimpleDateFormat formTime=new SimpleDateFormat("HH:mm:ss");
	public OverThread(TeacherSocket teacherSocket) {
		// TODO Auto-generated constructor stub
		this.teacherSocket=teacherSocket;
	}
	@Override
	@SuppressWarnings("unchecked")
	public void run() {
		System.out.println("����һ���߳�");
		// TODO Auto-generated method stub
		try {
//			BufferedWriter writer=teacherSocket.getBufferedWriter();
//			writer.write("requestConnect");
//			writer.newLine();
//			writer.flush();
			System.out.println(teacherSocket);
			ArrayList<Record> recordList=null;
			ArrayList<Record> tempList=null;
			//�����¼�¼(�Ȳ���û�в���ļ�¼�������л��Ķ����ǻ�û�в���ļ�¼�������ļ�¼���)
			recordList=(ArrayList<Record>)teacherSocket.getObjectInputStream().readObject();
			tempList=(ArrayList<Record>)teacherSocket.getObjectInputStream().readObject();
//			while(recordList.size()!=0||tempList.size()!=0) {
				System.out.println(recordList);
				System.out.println(tempList);
				System.out.println("-+-+-+-+-+-+-+--+--+-+-+-");
				System.out.println("�����ݿ��в�������");
				System.out.println("recordList����"+recordList.size());
				for(int i=0;i<recordList.size();i++) {
					System.out.println(recordList.get(i).getMacNumber());
//					try {
//						//database.insertRecord(recordList.get(i));
//					} catch (SQLException e) {
//						// TODO Auto-generated catch block
//						e.printStackTrace();
//					}
				}
				recordList=null;
				//������������ʱ��
				System.out.println("�����ݿ��и���ʱ��");
				System.out.println("tempList����"+tempList.size());
				Date date =new Date();
				for(int i=0;i<tempList.size();i++) {
//					System.out.println(tempList.get(i).getIpNumber());
					System.out.println(tempList.get(i).getMacNumber());
//					try {
//						database.updateRecord(formTime.format(date),tempList.get(i).getIpNumber(), tempList.get(i).getDate(), tempList.get(i).getFirstTime());
//					} catch (SQLException e) {
//						// TODO Auto-generated catch block
//						e.printStackTrace();
//					}
				}
				tempList=null;
//			}
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
