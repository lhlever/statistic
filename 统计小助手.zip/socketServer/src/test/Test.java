package test;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			ServerSocket serverSocket=new ServerSocket(3333);
			Socket socket=serverSocket.accept();
			ObjectInputStream objectInputStream=new ObjectInputStream(socket.getInputStream());
			ArrayList<Record> readObject = (ArrayList<Record>)objectInputStream.readObject();
			ArrayList<Record> list=readObject;
			for(int i=0;i<list.size();i++) {
				System.out.println(list.get(i).getRoomNumber()+"---"+list.get(i).getIpNumber());
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
