package test;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Socket socket;
		try {
			socket = new Socket("127.0.0.1", 3333);
			ArrayList<Record> list=new ArrayList<>();
			Record A=new Record();
			Record B=new Record();
			A.setRoomNumber("B101");
			B.setRoomNumber("B202");
			A.setIpNumber("192.168.167.253");
			B.setIpNumber("0.0.0.0");
			list.add(A);
			list.add(B);
			ObjectOutputStream objectOutputStream;
			objectOutputStream = new ObjectOutputStream(socket.getOutputStream());
			objectOutputStream.writeObject(list);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

}
