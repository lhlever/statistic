package udpTest;

import java.io.Serializable;

public class Record implements Serializable{
	private String roomNumber;
	private String ipNumber;
	private String macNumber;
	private String firstTime;
	private String lastTime;
	private String date;
	public Record(String roomNumber, String ipNumber, String macNumber, String firstTime, String lastTime,
			String date) {
		super();
		this.roomNumber = roomNumber;
		this.ipNumber = ipNumber;
		this.macNumber = macNumber;
		this.firstTime = firstTime;
		this.lastTime = lastTime;
		this.date = date;
	}
	public String getRoomNumber() {
		return roomNumber;
	}
	public void setRoomNumber(String roomNumber) {
		this.roomNumber = roomNumber;
	}
	public String getIpNumber() {
		return ipNumber;
	}
	public void setIpNumber(String ipNumber) {
		this.ipNumber = ipNumber;
	}
	public String getMacNumber() {
		return macNumber;
	}
	public void setMacNumber(String macNumber) {
		this.macNumber = macNumber;
	}
	public String getFirstTime() {
		return firstTime;
	}
	public void setFirstTime(String firstTime) {
		this.firstTime = firstTime;
	}
	public String getLastTime() {
		return lastTime;
	}
	public void setLastTime(String lastTime) {
		this.lastTime = lastTime;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	
}
