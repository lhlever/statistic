package udpTest;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class DataServer {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			System.out.println("���ݿ�������ѿ���");
			ServerSocket serverSocket=new ServerSocket(8000);
			while(true) {
				Socket socket=new Socket();
				socket=serverSocket.accept();
				System.out.println(socket.getRemoteSocketAddress()+"�Ѿ�����");
				ObjectInputStream reader=new ObjectInputStream(socket.getInputStream());
				ArrayList<Record> arrayList=(ArrayList<Record>)reader.readObject();
				System.out.println("-------------------�˴μ����й���"+arrayList.size()+"��Record����-------------------");
				for(Record record:arrayList) {
					System.out.println(record.getRoomNumber());
				}
				
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
