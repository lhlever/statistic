package udpTest;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
/*
 * ��������
 */
public class serverTCP {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			System.out.println("���ݿ�������ѿ���");
			ServerSocket serverSocket=new ServerSocket(8000);
			while(true) {
				Socket socket=new Socket();
				socket=serverSocket.accept();
				System.out.println(socket.getRemoteSocketAddress()+"�Ѿ�����");
				BufferedReader bufferedReader=new BufferedReader(new InputStreamReader(socket.getInputStream()));
				String temp=null;
				while((temp=bufferedReader.readLine())!=null) {
					System.out.println(temp);
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
