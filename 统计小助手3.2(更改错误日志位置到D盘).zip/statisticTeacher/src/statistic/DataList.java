package statistic;

import java.util.ArrayList;

public class DataList {
	private ArrayList<Record> arrayList=new ArrayList<>();
	public synchronized void add(Record record) {
		arrayList.add(record);
		System.out.println("������һ��Record����"+record);
	}
	public synchronized ArrayList<Record> getDataList() {
		return arrayList;
	}
	public synchronized void clear() {
		arrayList.clear();
	}
	public int getSize() {
		return arrayList.size();
	}
}
