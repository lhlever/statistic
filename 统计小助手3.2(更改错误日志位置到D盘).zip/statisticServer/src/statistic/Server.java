package statistic;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * ʹ��ǰ��ȷ��sqlserver�������������ⲻ��Ҫ���쳣
 * @author ever
 *
 */
public class Server {
//	static HashMap<String,String> hashMap=new HashMap<>();//******����ר��******
	static HashMap<String,String> B206=new HashMap<>();
	static HashMap<String,String> exception=new HashMap<>();//���ڴ�����ʦ��IP�ͻ�����û�н���ӳ�䣬��ӳ��������ʱ��ӳ��
	SimpleDateFormat formatTime = new SimpleDateFormat("HH:mm:ss");
	SimpleDateFormat formatDate = new SimpleDateFormat("yyyy-MM-dd");
	/**
	 * ����ip��ַ��ȡ������******����ר��******
	 * @param ipAddress ip��ַ
	 * @return 
	 */
	
	/*
	public String getRoomNumber(String ipAddress) {
		switch (ipAddress) {
			case "127.0.0.1":
				return "B206";
			default:
				return "";
		}
	}
	*/
	
	/**
	 * ����IP��ַ��ȡHashMap ���Ӹ��������Ľ�ʦ��IP
	 * @param ipAddress IP��ַ
	 * @return
	 */
	public HashMap<String,String> getHashMap(String ipAddress) {
		switch (ipAddress) {
			case "127.0.0.1":
				return B206;
			default:
				return exception;
		}
	}
	
	public static void main(String[] args) {
//		hashMap.put("127.0.0.1", "B206");//******����ר��******
		// TODO Auto-generated method stub
		System.out.println("���ݿ�������ѿ���");
		ExecutorService cachedThreadPool = Executors.newCachedThreadPool();
		ServerSocket serverSocket;
		try {
			serverSocket = new ServerSocket(8000);
			while(true) {
				@SuppressWarnings("resource")
				Socket socket=new Socket();
				socket=serverSocket.accept();
				cachedThreadPool.execute(new MyRunable(socket));
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			String path = "D:\\ErrorLog.txt";
			File file = new File(path);
			//true  ����׷��
			PrintWriter writer = null;
            FileWriter fileWrite;
			try {
				fileWrite = new FileWriter(String.valueOf(file), true);
				writer = new PrintWriter(fileWrite);
				writer.append(System.getProperty("line.separator") +"----------ʱ��:"+ new SimpleDateFormat("yyyy-MM-dd:HH:mm:ss").format(new Date())+"----------");
				writer.append(System.getProperty("line.separator"));
				writer.append("**********" + e.toString() + "**********");
				writer.append(System.getProperty("line.separator"));
				e.printStackTrace(writer);
				writer.flush();
				writer.close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}
}
//�߳��ڲ���
class MyRunable implements Runnable{
	Server server=new Server();
	private Socket socket;
	public MyRunable(Socket socket) {
		// TODO Auto-generated constructor stub
		this.socket=socket;
	}
	@Override
	public void run() {
		Date upToNow = new Date();
		System.out.println(Thread.currentThread().getName()+"---------�߳̿���");
		try {
			//socket.getRemoteSocketAddress().substring(1).split(":")[0]------���ǽ�ʦ��IP��ַ
			String ip=socket.getRemoteSocketAddress().toString().substring(1).split(":")[0];
//			System.out.println("�û�����IP��ַΪ"+ip);//******����ר��******
//			System.out.println(server.getRoomNumber(ip)+"�û�������");//******����ר��******
			ObjectInputStream reader=new ObjectInputStream(socket.getInputStream());
			@SuppressWarnings("unchecked")
			ArrayList<Record> arrayList=(ArrayList<Record>)reader.readObject();
			System.out.println("-------------------�˴μ����й���"+arrayList.size()+"��Record����-------------------");
			for(Record record:arrayList) {
				try {
					//���hashmap�д���
					if(server.getHashMap(ip).get(record.getMacNumber())==null) {
						System.out.println("������¼û�г�ʼ��");
						Database.insertRecord(record);
						server.getHashMap(ip).put(record.getMacNumber(),record.getFirstTime());
					}else {
						System.out.println("���¹�ϣ���е�ӳ���ϵ");
						//ͨ��ip��ַ�����ڣ����ε�¼ʱ��Ψһȷ��һ����¼��ѧ������firstTimeӦ����final�Ĳ��ɸ��ĵģ�
						Database.updateRecord(server.formatTime.format(upToNow), record.getMacNumber(), server.formatDate.format(upToNow), record.getFirstTime());
						server.getHashMap(ip).put(record.getMacNumber(), server.formatTime.format(upToNow));
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					String path = "D:\\ErrorLog.txt";
					File file = new File(path);
					//true  ����׷��
					PrintWriter writer = null;
	                FileWriter fileWrite;
					try {
						fileWrite = new FileWriter(String.valueOf(file), true);
						writer = new PrintWriter(fileWrite);
						writer.append(System.getProperty("line.separator") +"----------ʱ��:"+ new SimpleDateFormat("yyyy-MM-dd:HH:mm:ss").format(new Date())+"----------");
						writer.append(System.getProperty("line.separator"));
						writer.append("**********" + e.toString() + "**********");
						writer.append(System.getProperty("line.separator"));
						e.printStackTrace(writer);
						writer.flush();
						writer.close();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			}	
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			String path = "D:\\ErrorLog.txt";
			File file = new File(path);
			//true  ����׷��
			PrintWriter writer = null;
            FileWriter fileWrite;
			try {
				fileWrite = new FileWriter(String.valueOf(file), true);
				writer = new PrintWriter(fileWrite);
				writer.append(System.getProperty("line.separator") +"----------ʱ��:"+ new SimpleDateFormat("yyyy-MM-dd:HH:mm:ss").format(new Date())+"----------");
				writer.append(System.getProperty("line.separator"));
				writer.append("**********" + e.toString() + "**********");
				writer.append(System.getProperty("line.separator"));
				e.printStackTrace(writer);
				writer.flush();
				writer.close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			String path = "C:\\ErrorLog.txt";
			File file = new File(path);
			//true  ����׷��
			PrintWriter writer = null;
            FileWriter fileWrite;
			try {
				fileWrite = new FileWriter(String.valueOf(file), true);
				writer = new PrintWriter(fileWrite);
				writer.append(System.getProperty("line.separator") +"----------ʱ��:"+ new SimpleDateFormat("yyyy-MM-dd:HH:mm:ss").format(new Date())+"----------");
				writer.append(System.getProperty("line.separator"));
				writer.append("**********" + e.toString() + "**********");
				writer.append(System.getProperty("line.separator"));
				e.printStackTrace(writer);
				writer.flush();
				writer.close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}
	
	
	
}
