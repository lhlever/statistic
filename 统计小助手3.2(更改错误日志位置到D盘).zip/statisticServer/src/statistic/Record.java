package statistic;

import java.io.Serializable;

/**
 * ���ڴ���ļ�¼��
 * @author ever
 *
 */
public class Record implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String ipNumber;//IP��ַ
	private String macNumber;//MAC��ַ
	private String firstTime;//�������ӵ�ʱ�䣬�������µ�ʱ�����д�����ݿ�ʱ ��:12:00:00
	private String date;//���ӵ����� ��:2019-01-01
	public Record(String ipNumber, String macNumber, String firstTime,String date) {
		super();
		this.ipNumber = ipNumber;
		this.macNumber = macNumber;
		this.firstTime = firstTime;
		this.date = date;
	}
	public String getIpNumber() {
		return ipNumber;
	}
	public void setIpNumber(String ipNumber) {
		this.ipNumber = ipNumber;
	}
	public String getMacNumber() {
		return macNumber;
	}
	public void setMacNumber(String macNumber) {
		this.macNumber = macNumber;
	}
	public String getFirstTime() {
		return firstTime;
	}
	public void setFirstTime(String firstTime) {
		this.firstTime = firstTime;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	
}
